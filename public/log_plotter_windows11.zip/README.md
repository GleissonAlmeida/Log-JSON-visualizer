<div align="center">

# 📊 LogPlotter C &bull; JSON Data Log Visualizer

**Leitor de logs JSON de alta performance e plotador gráfico interativo desenvolvido em Linguagem C (ANSI C99) com exportação para Chart.js e binário nativo para Windows 11.**

[![Linguagem C](https://img.shields.io/badge/Language-C99-00599C?logo=c&logoColor=white)](https://en.wikipedia.org/wiki/C99)
[![Windows 11](https://img.shields.io/badge/Platform-Windows%2011%20%7C%20Linux-0078D4?logo=windows&logoColor=white)](https://microsoft.com/windows)
[![Chart.js](https://img.shields.io/badge/Graphics-Chart.js%20v4-FF6384?logo=chartdotjs&logoColor=white)](https://www.chartjs.org/)
[![Status](https://img.shields.io/badge/Build-Passing-brightgreen)](#compilação)
[![Licença](https://img.shields.io/badge/License-Apache--2.0-blue.svg)](LICENSE)

[Recursos](#-recursos-principais) &bull;
[Download Windows 11](#-download-do-executável-para-windows-11) &bull;
[Compilação](#-como-compilar-do-código-fonte) &bull;
[Uso & CLI](#-como-usar) &bull;
[Estrutura do Projeto](#-arquitetura-do-código) &bull;
[Formatos Suportados](#-formatos-de-log-json-aceitos)

</div>

---

## 🎯 Visão Geral

O **LogPlotter C** é uma solução de alta performance para análise e visualização de dados de telemetria (CAN Bus automotivo, sensores industriais, métricas de servidores e registros IoT) armazenados em formatos **CSV (.csv)**, **JSON (.json)** ou **JSONL (.log, .ndjson)**.

O projeto une a eficiência de processamento e alocação dinâmica de memória em **Linguagem C pura (ANSI C99)** com a interatividade moderna do **Chart.js**, gerando dashboards gráficos responsivos e autônomos.

---

## ✨ Recursos Principais

### 🎨 Temas e Propriedades Gráficas (Novo v2.7)
- **Alternância Dinâmica entre Tema Claro e Tema Escuro**:
  - **Tema Escuro**: fundo slate profundo (`#020617`), painéis `#0f172a`, eixos e grids com contraste suave (`rgba(51, 65, 85, 0.35)`).
  - **Tema Claro**: fundo limpo `#f8fafc`, painéis brancos puros (`#ffffff`), divisores discretos (`#e2e8f0`) e gridlines legíveis (`rgba(226, 232, 240, 0.9)`).
- **Estilos de Pontos no Tema Claro**:
  - `Núcleo Branco` *(Padrão Recomendado)*: núcleo em branco `#ffffff` com borda externa na cor do sinal (largura de 2.5px), garantindo máxima distinção visual e acabamento elegante.
  - `Borda Escura`: núcleo na cor do sinal com contorno escuro (`#0f172a`).
  - `Grafite Escuro`: núcleo em cinza escuro (`#1e293b`) com contorno da métrica.
  - `Personalizada`: seletor de cor hexadecimal livre para os marcadores pontuais.
- **Seletor Interativo de Cores por Variável**: cada métrica listada possui um seletor visual de cor (`<input type="color">`) que permite alterar a cor de qualquer curva em tempo real, refletindo na legenda, no cursor HUD e na exportação PNG.
- **Exportação PNG Adaptativa ao Tema**: gravação em imagem PNG de alta definição respeitando o tema ativo (fundo branco no modo claro, fundo escuro no modo dark, incluindo linha de cursor vertical, marcadores e cartão flutuante de inspeção).
- **Paridade Gráfica Total**: o executável C gera relatórios autônomos offline com exatamente as mesmas propriedades gráficas, paletas e funcionalidades do preview web.

### 📥 Ingestão e Leitura de Dados
- **Suporte Nativo a CSV (.csv)**: auto-detecção inteligente de separadores (vírgula `,`, ponto-e-vírgula `;`, tabulação `\t` e pipe `|`) com conversão de casas decimais com vírgula (ex: `12,50`).
- **Leitor Dinâmico de JSON / JSONL**: leitura de arrays JSON e arquivos JSON Lines com detecção automática de registros e propriedades numéricas.
- **Desaninhamento Automático (*Object Flattening*)**: converte nós aninhados como `{"sensores": {"temperatura": 24.5}}` em chaves acessíveis `sensores.temperatura`.
- **Detecção Inteligente**: identifica automaticamente campos temporais (`timestamp`, `horario`, `data`, `time`, `#`) e variáveis numéricas para plotagem.

### 📈 Gráficos Interativos (Chart.js)
- **Cursor Interativo do Eixo X**: inspeção de amostras em tempo real a 60 FPS com ponteiro do mouse, arrasto suave ou teclas direcionais (← / →), com opção de **Fixar Cursor**.
- **Hold de Telemetria (*Sample & Hold*)**: recupera o último valor válido recebido para sinais esparsos de CAN bus ou sensores assíncronos, exibindo tag visual `[hold]` no HUD.
- **Exportação PNG Completa**: grava imagem em alta definição registrando o traçado das curvas, a linha vertical tracejada do cursor, os marcadores e o cartão de inspeção com valores numéricos.
- **Separação Visual da Legenda**: espaçamento dedicado de 36px entre a legenda superior dos sinais e a área útil do gráfico, impedindo qualquer sobreposição do cursor.
- **Classificação de Sinais**: agrupamento inteligente que posiciona variáveis ativas no topo com divisor explicativo e ordenação alfabética (A-Z).
- **Eixo X Dinâmico**: selecione qualquer campo temporal ou utilize o índice sequencial numérico (`#1, #2, #3...`).
- **Eixos Y Múltiplos (Y, Y1, Y2)**: plote simultaneamente métricas de ordens de grandeza distintas em até três eixos independentes:
  - **Eixo Y**: esquerdo principal (cinza/slate)
  - **Eixo Y1**: direito 1 (azul celeste `#38bdf8`)
  - **Eixo Y2**: direito 2 (âmbar/dourado `#fbbf24`)
- **Ajuste da Escala do Eixo Y**:
  - Modo **Automático** ou **Manual** (com definição independente de valores mínimos e máximos para os eixos Y, Y1 e Y2).
  - Opção **Iniciar no zero (0)**.
  - Opção **Escala Logarítmica** para sinais com picos extremos.
- **Estilos Gráficos**: alternância instantânea entre **Linha**, **Área preenchida**, **Barras** e **Degraus** (*Stepped lines*).
- **Filtro de Faixa Temporal**: barra de rolagem interativa (*range scrubber*) com atalhos para `100%`, `50%`, `25%` e `Últimos 30` registros.
- **Painel Lateral com Seções Retráteis (Accordions)**: seções *Origem dos Dados*, *Eixo X*, *Estilo do Gráfico* e *Variáveis Selecionadas* podem ser recolhidas ou expandidas individualmente ou via atalho global *Recolher / Expandir*, reduzindo em mais de 60% o espaço vertical e eliminando a rolagem excessiva.

---

## 🖥️ Layout da Interface

```
+------------------------------------+---------------------------------------------------------------+
| PAINEL ESQUERDO (CONTROLES)        | PAINEL DIREITO (GRÁFICO INTERATIVO)                           |
+------------------------------------+---------------------------------------------------------------+
| 📁 Origem dos Dados JSON           | EIXO X: timestamp                                             |
|   [Carregar Arquivo JSON]          | Mostrando 60 de 60 registros (Ptos 1-60)                     |
|                                    | [100%] [50%] [25%] [Últimos 30]  [📥 Salvar PNG] [⛶ Tela Cheia]|
| 1. EIXO X (REFERÊNCIA HORIZONTAL)  |                                                               |
|   [ timestamp (Temporal)       v ] |  100 +-------●---●---●---●---●-------+ 1016 (Eixo Y1 Dir)     |
|                                    |      |       \                       |                        |
| 2. TIPO E ESTILO DO GRÁFICO        |   50 |        \      bateria_pct     | 1013                   |
|   [Linha] [Área] [Barras] [Degraus]|      |         \     pressao_hpa     |                        |
|   [x] Pontos no gráfico            |    0 +----------●---●---●---●-------+ 1010                   |
|   [x] Eixo Y duplo (L / R)         |      08:00    08:15    08:30    08:45                        |
|   -- Escala do Eixo Y --           +---------------------------------------------------------------+
|   [Auto] [Manual]                  | Filtro de Faixa Temporal: Ponto 1 até 60                      |
|   [ ] Iniciar em 0  [ ] Escala Log | Início: [===O=======================] 1                       |
|                                    | Fim:    [=======================O===] 60           [↺ Redefinir|
| 3. VARIÁVEIS SELECIONADAS (3/5)    +---------------------------------------------------------------+
|   🔍 [Filtrar variáveis...]        |
|   [x] ● bateria_pct   [Eixo Esq Y] |
|   [x] ● pressao_hpa   [Eixo Dir Y1]|
|   [x] ● temperatura   [Eixo Esq Y] |
+------------------------------------+
```

---

## 📦 Download do Executável para Windows 11

Não é necessário instalar compiladores, Python ou Node.js para rodar no Windows 11:

| Arquivo | Descrição | Link |
| :--- | :--- | :--- |
| **`log_plotter.exe`** | Executável nativo x86-64 compilado estaticamente (~356 KB) | [Baixar .EXE](/log_plotter.exe) |
| **`log_plotter_windows11.zip`** | Pacote completo com executável, dados de teste e script `.bat` (~149 KB) | [Baixar .ZIP](/log_plotter_windows11.zip) |

### 🚀 Execução Rápida em 2 Cliques no Windows 11:
1. Baixe e extraia o pacote `log_plotter_windows11.zip`.
2. Dê um duplo clique no arquivo **`executar_no_windows.bat`**.
3. O programa processará o log, calculará as métricas em C e abrirá a interface interativa automaticamente no navegador padrão (**Microsoft Edge**, **Google Chrome**, etc.).

---

## 🛠️ Como Compilar do Código-Fonte

O código-fonte em C está no diretório `src/c_src/` e segue o padrão **ANSI C99**, necessitando apenas da biblioteca padrão (`libc` e `libm`).

### No Linux / macOS (GCC ou Clang):
```bash
# Clone ou acesse a pasta do código:
cd src/c_src

# Compilação via Makefile:
make

# Ou compilação manual direta:
gcc -Wall -Wextra -O2 -std=c99 main.c json_parser.c -lm -o log_plotter
```

### No Windows (Cross-compilação com MinGW-w64):
```bash
x86_64-w64-mingw32-gcc -Wall -Wextra -O2 -std=c99 -static main.c json_parser.c -lm -o log_plotter.exe
```

---

## 💻 Como Usar (Linha de Comando)

```bash
# Execução direta com arquivo CSV (auto-detecta delimitador e colunas numéricas):
./log_plotter sample_can_bus.csv -x # --html grafico_c.html

# Execução básica com log JSON:
./log_plotter sample_iot.json

# Definindo o Eixo X e selecionando métricas específicas:
./log_plotter seu_arquivo.json -x timestamp -m temperatura,umidade,pressao_hpa

# No Windows (CMD / PowerShell):
.\log_plotter.exe sample_can_bus.csv --html grafico.html
start grafico.html
```

### Parâmetros Suportados:
- `<arquivo>` ou `-i <caminho>`: Caminho do arquivo CSV (`.csv`) ou JSON (`.json`, `.log`) de entrada.
- `-x <campo>`: Nome da coluna/chave usada como referência horizontal (Eixo X).
- `-m <m1,m2,...>`: Lista separada por vírgulas das variáveis para o gráfico.
- `--html <saida.html>`: Nome do arquivo HTML autônomo gerado (padrão: `grafico_c.html`).

---

## 📂 Arquitetura do Código

```
├── src/
│   ├── c_src/                      # Código-fonte em Linguagem C
│   │   ├── main.c                  # Leitor de arquivos, pipeline CLI, gerador HTML e lógica
│   │   ├── json_parser.h           # Header do analisador sintático de JSON
│   │   ├── json_parser.c           # Implementação do parser JSON em C99 puro
│   │   ├── Makefile                # Script de compilação automatizada
│   │   ├── sample_iot.json         # Log de telemetria de exemplo
│   │   └── README.md               # Documentação técnica em C
│   │
│   ├── components/                 # Componentes React (Web App)
│   │   ├── ChartViewer.tsx         # Renderizador do gráfico Chart.js
│   │   ├── MetricSelector.tsx      # Painel de controles (Eixo X, estilos, escala Y, métricas)
│   │   └── JsonInputModal.tsx      # Modal de carregamento e colagem de logs JSON
│   │
│   ├── utils/
│   │   ├── jsonParser.ts           # Parser cliente com desaninhamento e estatísticas
│   │   └── cExecutionEngine.ts     # Emulador do pipeline de execução C
│   └── App.tsx                     # Orquestrador da interface do usuário
│
├── public/
│   ├── log_plotter.exe             # Binário compilado estático para Windows 11
│   ├── log_plotter_windows11.zip   # Pacote de distribuição pronto para Windows
│   ├── executar_no_windows.bat     # Script de inicialização em 2 cliques
│   └── sample_iot.json             # Dataset de demonstração
│
└── README.md                       # Esta documentação
```

---

## 📄 Formatos de Log JSON Aceitos

O analisador aceita automaticamente diversas estruturas de arquivos de log:

### 1. Array de Objetos JSON (Padrão):
```json
[
  { "timestamp": "08:00:00", "temperatura": 22.4, "pressao_hpa": 1013.2, "bateria_pct": 98.0 },
  { "timestamp": "08:01:00", "temperatura": 22.8, "pressao_hpa": 1013.1, "bateria_pct": 97.8 }
]
```

### 2. Objeto com Array Encapsulado:
```json
{
  "device": "ESP32-STATION",
  "data": [
    { "time": "12:00:00", "cpu": 45.2, "ram_mb": 1820 },
    { "time": "12:00:30", "cpu": 52.8, "ram_mb": 1845 }
  ]
}
```

### 3. Objetos Aninhados (Desaninhamento Automático):
```json
[
  {
    "timestamp": "2026-10-25T10:00:00Z",
    "sensores": {
      "temperatura": 26.5,
      "umidade": 54.0
    }
  }
]
```
*(As propriedades são convertidas automaticamente em `sensores.temperatura` e `sensores.umidade`)*.

### 4. JSON Lines & Telemetria Veicular CAN Bus (NDJSON Intercalado):
```json
{"#":1,"BrakeSwitch":1.0,"WheelBasedVehicleSpeed":0.00}
{"#":2,"curr_gear":2.0,"sel_gear":2.0}
{"#":3,"BrakeSwitch":1.0,"WheelBasedVehicleSpeed":0.00}
{"#":4,"curr_gear":2.0,"sel_gear":2.0}
```
*(O campo `"#"` é detectado automaticamente como o índice sequencial de amostragem horizontal. O algoritmo unifica esquemas esparsos e aplica **Zero-Order Hold (Sample & Hold)** e `spanGaps`, mantendo curvas de velocidade, freio e marcha contínuas sem quedas a zero)*.

---

## 📜 Licença

Distribuído sob a licença **Apache 2.0**. Consulte o arquivo de licença para mais informações.
